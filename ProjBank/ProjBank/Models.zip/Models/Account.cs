﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace ProjBank.Models
{
    public class Account
    {
        public int Id { get; set; }
        [EmailAddress(ErrorMessage = "Please enter a valid email address")]
        public string Owner { get; set; }
        [EmailAddress(ErrorMessage = "Please enter a valid email address")]
        public string Recipient { get; set; }
        [Required]
        public string name { get; set; }

        [Editable(false)]
        public DateTime OpenDate = DateTime.Today;
        [Range(0, 100, ErrorMessage = "Interest Rate cannot less than 0 or greater than 100")]
        public int InterestRate { get; set; }

        public decimal getTotalAmount
        {
            get
            {
                decimal count = 0;
                if (Transactions != null)
                {
                    for (int i = 0; i < Transactions.Count(); i++)
                    {
                        count = count + Transactions[i].transactionAmount;
                    }
                }
                return count;
                ;
            }
        }


        public DateTime? GetLastTransactionDate
        {
            get
            {
                if (Transactions != null && Transactions.Count()!=0)
                {
                    return Transactions[Transactions.Count() - 1].transactionDate;
                }
                else
                {
                    return null;
                }
            }
        }

        public void YTDinterestEarned()
        {

        }
        public virtual List<Transaction> Transactions { get; set; }
        public Account()
        {
            Transactions = new List<Transaction>();
        }
    }
}